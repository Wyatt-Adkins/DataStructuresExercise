// 1a
const jedi = [];
// 1b
jedi.push =("luke");
// 1c
jedi.push("Obi-Wan Kenobi");
// 1d
console.log(jedi.unshift("yoda"))